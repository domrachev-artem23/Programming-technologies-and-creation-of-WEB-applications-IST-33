CREATE TABLE IF NOT EXISTS users (
 id SERIAL PRIMARY KEY, full_name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('patient','doctor','admin')) DEFAULT 'patient',
 created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS patient_profiles (
 id SERIAL PRIMARY KEY, user_id INT UNIQUE REFERENCES users(id) ON DELETE CASCADE,
 birth_date DATE, phone TEXT
);
CREATE TABLE IF NOT EXISTS clinics (
 id SERIAL PRIMARY KEY, name TEXT NOT NULL, address TEXT NOT NULL, latitude DOUBLE PRECISION,
 longitude DOUBLE PRECISION, phone TEXT, working_hours TEXT
);
CREATE TABLE IF NOT EXISTS specialties (id SERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS doctors (
 id SERIAL PRIMARY KEY, user_id INT REFERENCES users(id), full_name TEXT NOT NULL,
 specialty_id INT REFERENCES specialties(id), experience_years INT DEFAULT 0,
 clinic_id INT REFERENCES clinics(id), bio TEXT
);
CREATE TABLE IF NOT EXISTS doctor_schedules (
 id SERIAL PRIMARY KEY, doctor_id INT REFERENCES doctors(id) ON DELETE CASCADE,
 starts_at TIMESTAMPTZ NOT NULL, is_booked BOOLEAN DEFAULT false
);
CREATE TABLE IF NOT EXISTS appointments (
 id SERIAL PRIMARY KEY, patient_id INT REFERENCES users(id), doctor_id INT REFERENCES doctors(id),
 starts_at TIMESTAMPTZ NOT NULL, reason TEXT, status TEXT DEFAULT 'Запланирована',
 created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS health_measurements (
 id SERIAL PRIMARY KEY, patient_id INT REFERENCES users(id), metric TEXT NOT NULL,
 value NUMERIC NOT NULL, unit TEXT NOT NULL, measured_at TIMESTAMPTZ DEFAULT now(),
 source TEXT DEFAULT 'Вручную', comment TEXT
);
CREATE TABLE IF NOT EXISTS lab_tests (
 id SERIAL PRIMARY KEY, patient_id INT REFERENCES users(id), name TEXT NOT NULL,
 conducted_at DATE, clinic_id INT REFERENCES clinics(id), status TEXT DEFAULT 'Готов',
 attachment_name TEXT
);
CREATE TABLE IF NOT EXISTS lab_test_results (
 id SERIAL PRIMARY KEY, test_id INT REFERENCES lab_tests(id) ON DELETE CASCADE,
 name TEXT NOT NULL, value NUMERIC, unit TEXT, reference_min NUMERIC, reference_max NUMERIC
);
CREATE TABLE IF NOT EXISTS medical_records (
 id SERIAL PRIMARY KEY, patient_id INT REFERENCES users(id), category TEXT NOT NULL,
 title TEXT NOT NULL, description TEXT, author TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS recommendations (
 id SERIAL PRIMARY KEY, patient_id INT REFERENCES users(id), category TEXT NOT NULL,
 title TEXT NOT NULL, description TEXT NOT NULL, basis TEXT, status TEXT DEFAULT 'Новая',
 created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS notifications (
 id SERIAL PRIMARY KEY, user_id INT REFERENCES users(id), title TEXT NOT NULL,
 body TEXT, kind TEXT, is_read BOOLEAN DEFAULT false, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS ai_messages (
 id SERIAL PRIMARY KEY, user_id INT REFERENCES users(id), role TEXT NOT NULL,
 content TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id SERIAL PRIMARY KEY, actor_id INT REFERENCES users(id), action TEXT NOT NULL,
 entity TEXT, entity_id INT, created_at TIMESTAMPTZ DEFAULT now()
);
