INSERT INTO users(full_name,email,password_hash,role) VALUES
('Иванова Анна','anna@example.test','demo1234','patient'),
('Петров Михаил','doctor@example.test','demo1234','doctor')
ON CONFLICT(email) DO NOTHING;
INSERT INTO patient_profiles(user_id,birth_date,phone)
SELECT id,'1992-04-12','+41 00 000 00 00' FROM users WHERE email='anna@example.test'
ON CONFLICT(user_id) DO NOTHING;
INSERT INTO clinics(name,address,latitude,longitude,phone,working_hours)
SELECT 'Клиника Здоровье','ул. Лесная, 24',47.3769,8.5417,'+41 44 000 00 00','Пн–Пт 08:00–18:00'
WHERE NOT EXISTS (SELECT 1 FROM clinics WHERE name='Клиника Здоровье');
INSERT INTO specialties(name) VALUES ('Терапевт'),('Кардиолог'),('Эндокринолог') ON CONFLICT DO NOTHING;
INSERT INTO doctors(full_name,specialty_id,experience_years,clinic_id,bio)
SELECT 'Смирнов Алексей',s.id,12,c.id,'Врач общей практики. Демонстрационный профиль.'
FROM specialties s CROSS JOIN clinics c WHERE s.name='Терапевт' AND c.name='Клиника Здоровье'
AND NOT EXISTS (SELECT 1 FROM doctors WHERE full_name='Смирнов Алексей');
INSERT INTO health_measurements(patient_id,metric,value,unit,measured_at,source)
SELECT u.id,x.metric,x.val,x.unit,now() - (x.days||' days')::interval,'Демо-устройство'
FROM users u CROSS JOIN (VALUES
('Пульс',72,'уд/мин',0),('SpO₂',98,'%',0),('Температура',36.6,'°C',0),('Шаги',8432,'шагов',0),
('Пульс',75,'уд/мин',1),('SpO₂',97,'%',1),('Температура',36.5,'°C',1),('Шаги',7900,'шагов',1),
('Пульс',70,'уд/мин',2),('SpO₂',98,'%',2),('Температура',36.7,'°C',2),('Шаги',9100,'шагов',2)
) AS x(metric,val,unit,days) WHERE u.email='anna@example.test'
AND NOT EXISTS (SELECT 1 FROM health_measurements WHERE patient_id=u.id);
INSERT INTO lab_tests(patient_id,name,conducted_at,status)
SELECT id,'Общий анализ крови',CURRENT_DATE - 2,'Готов' FROM users WHERE email='anna@example.test'
AND NOT EXISTS (SELECT 1 FROM lab_tests WHERE name='Общий анализ крови');
INSERT INTO recommendations(patient_id,category,title,description,basis)
SELECT id,'Активность','Добавьте прогулку','Попробуйте включить короткую прогулку в распорядок дня.','Демонстрационный пример на основе шагов.'
FROM users WHERE email='anna@example.test'
AND NOT EXISTS (SELECT 1 FROM recommendations WHERE title='Добавьте прогулку');
INSERT INTO notifications(user_id,title,body,kind)
SELECT id,'Добро пожаловать в HealthHub AI','Это учебное уведомление. Данные в системе демонстрационные.','info'
FROM users WHERE email='anna@example.test'
AND NOT EXISTS (SELECT 1 FROM notifications WHERE title='Добро пожаловать в HealthHub AI');
