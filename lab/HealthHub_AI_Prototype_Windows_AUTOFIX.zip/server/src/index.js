import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import pg from 'pg';
dotenv.config();
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const app = express();
app.use(cors({ origin: true }));
app.use(express.json());
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret';
function auth(req,res,next){
  const token=(req.headers.authorization||'').replace('Bearer ','');
  try { req.user=jwt.verify(token,JWT_SECRET); next(); }
  catch { return res.status(401).json({error:'Требуется авторизация'}); }
}
app.post('/api/auth/login', async(req,res)=>{
  const {email,password}=req.body;
  const q=await pool.query('SELECT id,full_name,email,role,password_hash FROM users WHERE email=$1',[email]);
  const u=q.rows[0];
  if(!u || u.password_hash!==password) return res.status(401).json({error:'Неверные данные'});
  const token=jwt.sign({id:u.id,role:u.role},JWT_SECRET,{expiresIn:'8h'});
  res.json({token,user:{id:u.id,name:u.full_name,email:u.email,role:u.role}});
});
app.get('/api/me',auth,async(req,res)=>{
 const q=await pool.query('SELECT id,full_name,email,role FROM users WHERE id=$1',[req.user.id]); res.json(q.rows[0]);
});
app.get('/api/dashboard',auth,async(req,res)=>{
 const m=await pool.query(`SELECT DISTINCT ON(metric) metric,value,unit,measured_at FROM health_measurements WHERE patient_id=$1 ORDER BY metric,measured_at DESC`,[req.user.id]);
 const a=await pool.query(`SELECT a.id,a.starts_at,a.status,d.full_name AS doctor,s.name AS specialty,c.name AS clinic FROM appointments a JOIN doctors d ON d.id=a.doctor_id LEFT JOIN specialties s ON s.id=d.specialty_id LEFT JOIN clinics c ON c.id=d.clinic_id WHERE a.patient_id=$1 ORDER BY starts_at LIMIT 5`,[req.user.id]);
 const n=await pool.query('SELECT count(*)::int AS unread FROM notifications WHERE user_id=$1 AND is_read=false',[req.user.id]);
 res.json({metrics:m.rows,appointments:a.rows,unread:n.rows[0].unread});
});
app.get('/api/measurements',auth,async(req,res)=>{
 const {period='7'}=req.query;
 const days=Math.min(Math.max(parseInt(period)||7,1),90);
 const q=await pool.query(`SELECT * FROM health_measurements WHERE patient_id=$1 AND measured_at >= now()-($2||' days')::interval ORDER BY measured_at`,[req.user.id,String(days)]);
 res.json(q.rows);
});
app.post('/api/measurements',auth,async(req,res)=>{
 const {metric,value,unit,source='Вручную',comment=''}=req.body;
 const ranges={'Пульс':[25,240],'SpO₂':[50,100],'Температура':[30,45],'Шаги':[0,100000],'Сон':[0,24]};
 if(!ranges[metric] || !Number.isFinite(Number(value)) || Number(value)<ranges[metric][0] || Number(value)>ranges[metric][1])
   return res.status(400).json({error:'Проверьте тип показателя и допустимое значение'});
 const q=await pool.query('INSERT INTO health_measurements(patient_id,metric,value,unit,source,comment) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[req.user.id,metric,value,unit,source,comment]);
 res.status(201).json(q.rows[0]);
});
app.get('/api/doctors',auth,async(req,res)=>{
 const q=await pool.query('SELECT d.id,d.full_name,d.experience_years,d.bio,s.name AS specialty,c.name AS clinic FROM doctors d LEFT JOIN specialties s ON s.id=d.specialty_id LEFT JOIN clinics c ON c.id=d.clinic_id ORDER BY d.full_name');
 res.json(q.rows);
});
app.post('/api/appointments',auth,async(req,res)=>{
 const {doctor_id,starts_at,reason=''}=req.body;
 const client=await pool.connect();
 try {
  await client.query('BEGIN');
  const exists=await client.query("SELECT id FROM appointments WHERE doctor_id=$1 AND starts_at=$2 AND status <> 'Отменена' FOR UPDATE",[doctor_id,starts_at]);
  if(exists.rowCount){await client.query('ROLLBACK');return res.status(409).json({error:'Это время уже занято'});}
  const q=await client.query("INSERT INTO appointments(patient_id,doctor_id,starts_at,reason) VALUES($1,$2,$3,$4) RETURNING *",[req.user.id,doctor_id,starts_at,reason]);
  await client.query('COMMIT'); res.status(201).json(q.rows[0]);
 } catch(e){await client.query('ROLLBACK');res.status(500).json({error:'Не удалось создать запись'});}
 finally{client.release();}
});
app.get('/api/labs',auth,async(req,res)=>{
 const q=await pool.query('SELECT * FROM lab_tests WHERE patient_id=$1 ORDER BY conducted_at DESC',[req.user.id]);res.json(q.rows);
});
app.get('/api/records',auth,async(req,res)=>{
 const q=await pool.query('SELECT * FROM medical_records WHERE patient_id=$1 ORDER BY created_at DESC',[req.user.id]);res.json(q.rows);
});
app.get('/api/recommendations',auth,async(req,res)=>{
 const q=await pool.query('SELECT * FROM recommendations WHERE patient_id=$1 ORDER BY created_at DESC',[req.user.id]);res.json(q.rows);
});
app.patch('/api/recommendations/:id',auth,async(req,res)=>{
 const q=await pool.query('UPDATE recommendations SET status=$1 WHERE id=$2 AND patient_id=$3 RETURNING *',[req.body.status,req.params.id,req.user.id]);
 if(!q.rowCount)return res.status(404).json({error:'Не найдено'});res.json(q.rows[0]);
});
app.get('/api/notifications',auth,async(req,res)=>{
 const q=await pool.query('SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC',[req.user.id]);res.json(q.rows);
});
app.post('/api/ai/chat',auth,async(req,res)=>{
 const question=String(req.body.message||'').trim(); if(!question)return res.status(400).json({error:'Введите вопрос'});
 const lower=question.toLowerCase();
 let answer='Я могу предоставить общую справочную информацию. Для персональной оценки обратитесь к врачу. Я не ставлю диагнозы и не назначаю лечение.';
 if(lower.includes('анализ')) answer='Результаты анализов следует оценивать вместе с симптомами, анамнезом и референсными интервалами конкретной лаборатории. Если пришлёте название показателя и диапазон, я помогу объяснить общие термины. Это не диагноз.';
 else if(lower.includes('сон')) answer='Для режима сна полезны стабильное время отхода ко сну, спокойный вечерний ритуал и ограничение яркого света перед сном. При стойких нарушениях обсудите их с врачом.';
 else if(lower.includes('витамин d')) answer='Вопросы дозировки витамина D зависят от анализа, возраста и индивидуальных факторов. Не начинайте высокие дозы без консультации специалиста.';
 else if(lower.includes('серд')||lower.includes('упраж')) answer='Уровень физической активности следует увеличивать постепенно и с учётом самочувствия. При боли в груди, выраженной одышке или обмороке нужна срочная медицинская помощь.';
 await pool.query("INSERT INTO ai_messages(user_id,role,content) VALUES($1,'user',$2),($1,'assistant',$3)",[req.user.id,question,answer]);
 res.json({answer,disclaimer:'Информационный ответ учебного ассистента, не медицинская рекомендация.'});
});
app.get('/api/clinics',auth,async(req,res)=>{const q=await pool.query('SELECT * FROM clinics ORDER BY name');res.json(q.rows);});
app.get('/api/report.csv',auth,async(req,res)=>{
 const q=await pool.query('SELECT metric,value,unit,measured_at,source FROM health_measurements WHERE patient_id=$1 ORDER BY measured_at',[req.user.id]);
 const rows=['Показатель,Значение,Единица,Дата,Источник',...q.rows.map(x=>[x.metric,x.value,x.unit,x.measured_at.toISOString(),x.source].map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(','))];
 res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="healthhub-report.csv"');res.send('\\uFEFF'+rows.join('\\n'));
});
app.listen(process.env.PORT||4000,()=>console.log('HealthHub API listening'));
