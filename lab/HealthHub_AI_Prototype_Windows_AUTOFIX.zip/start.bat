@echo off
setlocal EnableExtensions
chcp 65001 >nul
title HealthHub AI launcher
cd /d "%~dp0"

echo.
echo ==========================================
echo          HealthHub AI - START
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found.
  echo Install Node.js 20 or newer from https://nodejs.org/
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found.
  pause
  exit /b 1
)

if not exist "server\package.json" (
  echo ERROR: server\package.json is missing. Extract the complete ZIP first.
  pause
  exit /b 1
)
if not exist "client\package.json" (
  echo ERROR: client\package.json is missing. Extract the complete ZIP first.
  pause
  exit /b 1
)

rem Create the environment file automatically when it is missing.
if not exist "server\.env" (
  if not exist "server\.env.example" (
    echo ERROR: Both server\.env and server\.env.example are missing.
    pause
    exit /b 1
  )
  copy /Y "server\.env.example" "server\.env" >nul
  if errorlevel 1 (
    echo ERROR: Could not create server\.env.
    pause
    exit /b 1
  )
  echo.
  echo Created server\.env from the example file.
  echo Notepad will open. Check your PostgreSQL username and password.
  echo Save the file and CLOSE Notepad to continue.
  start /wait "" notepad "%~dp0server\.env"
)

echo.
echo Node.js version:
node -v
echo npm version:
call npm -v
echo.

if not exist "server\node_modules" (
  echo Installing server packages...
  pushd "server"
  call npm install
  if errorlevel 1 (
    echo ERROR: Server package installation failed.
    popd
    pause
    exit /b 1
  )
  popd
) else (
  echo Server packages already installed.
)

if not exist "client\node_modules" (
  echo Installing client packages...
  pushd "client"
  call npm install
  if errorlevel 1 (
    echo ERROR: Client package installation failed.
    popd
    pause
    exit /b 1
  )
  popd
) else (
  echo Client packages already installed.
)

echo Starting API server in a new window...
start "HealthHub API" cmd /k "cd /d ""%~dp0server"" && npm run dev"

timeout /t 3 /nobreak >nul

echo Starting web client in a new window...
start "HealthHub Web" cmd /k "cd /d ""%~dp0client"" && npm run dev"

echo.
echo ==========================================
echo Startup commands have been sent.
echo Open: http://localhost:5173
echo API:  http://localhost:4000
echo Close API and Web terminal windows to stop.
echo ==========================================
echo.
pause
endlocal
